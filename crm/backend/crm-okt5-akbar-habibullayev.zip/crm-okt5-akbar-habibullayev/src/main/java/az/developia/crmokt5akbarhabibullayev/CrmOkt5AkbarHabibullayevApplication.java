package az.developia.crmokt5akbarhabibullayev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrmOkt5AkbarHabibullayevApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrmOkt5AkbarHabibullayevApplication.class, args);
	}

}
