package az.developia.crmokt5akbarhabibullayev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrmOkt5AkbarHabibullayevApplicationTests {

	@Test
	void contextLoads() {
	}

}
